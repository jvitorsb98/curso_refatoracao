package br.com.alura.adopet.api.model;

public enum ProbabilidadeAdocao {

    BAIXA,
    MEDIA,
    ALTA;

}
